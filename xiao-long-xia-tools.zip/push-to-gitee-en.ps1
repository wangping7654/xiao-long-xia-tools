# Push memory to Gitee cloud backup
Write-Host "=== Push memory to Gitee cloud ==="
Write-Host "Repo: https://gitee.com/little-dragon-shrimp/memory-backup.git"
Write-Host ""

# Change to workspace
Set-Location "C:\Users\89198\.openclaw\workspace"

# Check status
Write-Host "[INFO] Checking Git status..."
git status

Write-Host ""
Write-Host "[INFO] Adding all changes..."
git add .

Write-Host "[INFO] Committing changes..."
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
git commit -m "Auto backup: $timestamp - Xiao Long Xia memory sync"

Write-Host ""
Write-Host "[ACTION] Pushing to Gitee..."
Write-Host "Note: May need username and password"
Write-Host "Username: little-dragon-shrimp"
Write-Host "Password: Wp4592166++"
Write-Host ""

# Try to push
git push -u origin master

Write-Host ""
if ($LASTEXITCODE -eq 0) {
    Write-Host "[SUCCESS] Memory successfully synced to Gitee cloud!"
    Write-Host "Visit: https://gitee.com/little-dragon-shrimp/memory-backup"
} else {
    Write-Host "[ERROR] Push failed, error code: $LASTEXITCODE"
    Write-Host "May need manual authentication or check network"
}