// 测试飞书API的简单脚本
const https = require('https');

const appId = 'cli_a908558576fadcb5';
const appSecret = 'QZOOqYvV6f6A3Bg3OGdytcBTOrNz2aeE';

console.log('测试飞书API连接...');
console.log('App ID:', appId);
console.log('App Secret:', appSecret.substring(0, 10) + '...'); // 只显示前10位

// 获取访问令牌的请求
const postData = JSON.stringify({
  app_id: appId,
  app_secret: appSecret
});

const options = {
  hostname: 'open.feishu.cn',
  port: 443,
  path: '/open-apis/auth/v3/tenant_access_token/internal',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': postData.length
  }
};

console.log('\n发送请求到飞书API...');
const req = https.request(options, (res) => {
  console.log('状态码:', res.statusCode);
  console.log('响应头:', JSON.stringify(res.headers));
  
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log('\n响应内容:');
    try {
      const result = JSON.parse(data);
      console.log(JSON.stringify(result, null, 2));
      
      if (result.code === 0) {
        console.log('\n✅ 成功获取访问令牌！');
        console.log('令牌:', result.tenant_access_token.substring(0, 20) + '...');
        console.log('过期时间:', result.expire, '秒');
      } else {
        console.log('\n❌ 获取令牌失败:');
        console.log('错误码:', result.code);
        console.log('错误信息:', result.msg);
      }
    } catch (e) {
      console.log('解析响应失败:', e.message);
      console.log('原始数据:', data);
    }
  });
});

req.on('error', (e) => {
  console.error('请求错误:', e.message);
});

req.write(postData);
req.end();