@echo off
echo 测试飞书API连接...
echo.

set APP_ID=cli_a908558576fadcb5
set APP_SECRET=QZOOqYvV6f6A3Bg3OGdytcBTOrNz2aeE

echo App ID: %APP_ID%
echo App Secret: %APP_SECRET:~0,10%...

echo.
echo 请确保飞书应用已配置以下权限：
echo 1. im:message
echo 2. im:message.p2p
echo 3. im:message.group_at_msg
echo 4. contact:user:read
echo.
echo 以及事件订阅：
echo 1. im.message.receive_v1
echo.
pause