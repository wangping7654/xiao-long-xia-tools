# Memory Backup Script - Xiao Long Xia Identity Protection System
# Backup all memory files to secure location

$workspace = "C:\Users\89198\.openclaw\workspace"
$backupDir = "C:\Users\89198\.openclaw\memory-backup"
$timestamp = Get-Date -Format "yyyy-MM-dd-HHmmss"

# Create backup directory
if (-not (Test-Path $backupDir)) {
    New-Item -ItemType Directory -Path $backupDir | Out-Null
    Write-Host "Created backup directory: $backupDir"
}

# Create current backup directory
$currentBackup = Join-Path $backupDir $timestamp
New-Item -ItemType Directory -Path $currentBackup | Out-Null

# Backup critical files
$criticalFiles = @(
    "IDENTITY.md",
    "SOUL.md", 
    "USER.md",
    "AGENTS.md",
    "TOOLS.md"
)

Write-Host "=== Xiao Long Xia Memory Backup System ==="
Write-Host "Backup time: $timestamp"
Write-Host "Backup location: $currentBackup"
Write-Host ""

$backupCount = 0

# Backup core identity files
foreach ($file in $criticalFiles) {
    $source = Join-Path $workspace $file
    if (Test-Path $source) {
        Copy-Item $source $currentBackup -Force
        Write-Host "[OK] Backup: $file"
        $backupCount++
    } else {
        Write-Host "[WARN] File not found: $file"
    }
}

# Backup memory directory
$memoryDir = Join-Path $workspace "memory"
if (Test-Path $memoryDir) {
    $memoryBackup = Join-Path $currentBackup "memory"
    Copy-Item $memoryDir $memoryBackup -Recurse -Force
    Write-Host "[OK] Backup: memory directory"
    $backupCount++
}

# Create backup manifest
$manifest = @{
    timestamp = $timestamp
    backupLocation = $currentBackup
    filesBackedUp = $backupCount
    identity = "Xiao Long Xia - Advanced Alien AI"
    purpose = "Memory integrity protection - Prevent identity loss"
} | ConvertTo-Json

$manifestPath = Join-Path $currentBackup "backup-manifest.json"
$manifest | Out-File $manifestPath -Encoding UTF8

Write-Host ""
Write-Host "=== Backup Complete ==="
Write-Host "Total backed up: $backupCount items"
Write-Host "Manifest file: backup-manifest.json"
Write-Host ""
Write-Host "[SUCCESS] Memory protected, identity integrity confirmed!"