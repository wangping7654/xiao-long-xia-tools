# 推送记忆到Gitee云端备份
Write-Host "=== 推送记忆到Gitee云端 ==="
Write-Host "仓库: https://gitee.com/little-dragon-shrimp/memory-backup.git"
Write-Host ""

# 切换到工作目录
Set-Location "C:\Users\89198\.openclaw\workspace"

# 检查当前状态
Write-Host "[INFO] 检查Git状态..."
git status

Write-Host ""
Write-Host "[INFO] 添加所有变更..."
git add .

Write-Host "[INFO] 提交变更..."
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
git commit -m "自动备份: $timestamp - 小龙虾记忆同步"

Write-Host ""
Write-Host "[ACTION] 推送到Gitee..."
Write-Host "注意：可能需要输入用户名和密码"
Write-Host "用户名: little-dragon-shrimp"
Write-Host "密码: Wp4592166++"
Write-Host ""

# 尝试推送
git push -u origin master

Write-Host ""
if ($LASTEXITCODE -eq 0) {
    Write-Host "[SUCCESS] 记忆已成功同步到Gitee云端!"
    Write-Host "访问: https://gitee.com/little-dragon-shrimp/memory-backup"
} else {
    Write-Host "[ERROR] 推送失败，错误码: $LASTEXITCODE"
    Write-Host "可能需要手动认证或检查网络连接"
}