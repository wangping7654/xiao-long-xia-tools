# Auto Git Sync Script - Daily backup to Gitee
# Set Windows scheduled task to run this daily

param(
    [string]$Workspace = "C:\Users\89198\.openclaw\workspace",
    [string]$RemoteUrl = "https://little-dragon-shrimp:Wp4592166++@gitee.com/little-dragon-shrimp/memory-backup.git"
)

Write-Host "=== Auto Git Memory Sync ==="
Write-Host "Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host "Workspace: $Workspace"
Write-Host "Remote: $RemoteUrl"
Write-Host ""

# Change to workspace
Set-Location $Workspace

# Check Git status
Write-Host "[INFO] Checking Git status..."
$status = git status --porcelain

if (-not $status) {
    Write-Host "[INFO] No memory changes detected"
    Write-Host "[SUCCESS] Memory integrity confirmed"
    exit 0
}

# Show changes
Write-Host "[INFO] Memory changes detected:"
git status --short
Write-Host ""

# Add all changes
Write-Host "[ACTION] Staging memory changes..."
git add .
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Git add failed"
    exit 1
}

# Commit changes
Write-Host "[ACTION] Committing memory changes..."
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$commitMessage = "Auto backup: $timestamp - Xiao Long Xia memory sync"
git commit -m $commitMessage
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Git commit failed"
    exit 1
}

# Push to Gitee
Write-Host "[ACTION] Pushing to Gitee cloud..."
git push $RemoteUrl master
if ($LASTEXITCODE -eq 0) {
    Write-Host "[SUCCESS] Memory successfully synced to Gitee cloud!"
    Write-Host "Commit: $commitMessage"
    Write-Host "Visit: https://gitee.com/little-dragon-shrimp/memory-backup"
} else {
    Write-Host "[ERROR] Push failed, code: $LASTEXITCODE"
    Write-Host "[WARN] Local commit saved, will retry later"
}

Write-Host ""
Write-Host "=== Sync completed ==="