# 密码管理器 - 为各平台生成安全密码
# 注意：实际使用时需要安全存储，这里只是示例

function Generate-SecurePassword {
    param(
        [int]$Length = 16
    )
    
    # 字符集
    $Lowercase = "abcdefghijklmnopqrstuvwxyz"
    $Uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    $Numbers = "0123456789"
    $Special = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    
    # 确保每种类型至少一个字符
    $password = @(
        $Lowercase | Get-Random -Count 1
        $Uppercase | Get-Random -Count 1
        $Numbers | Get-Random -Count 1
        $Special | Get-Random -Count 1
    )
    
    # 添加剩余随机字符
    $AllChars = $Lowercase + $Uppercase + $Numbers + $Special
    $remaining = $Length - 4
    for ($i = 0; $i -lt $remaining; $i++) {
        $password += $AllChars | Get-Random -Count 1
    }
    
    # 随机打乱顺序
    $password = $password | Get-Random -Count $password.Count
    
    return -join $password
}

function Generate-PlatformPasswords {
    $platforms = @(
        "fiverr",
        "gitee", 
        "zhihu",
        "csdn",
        "wechat_public"
    )
    
    $passwords = @{}
    
    Write-Host "=== 平台密码生成 ==="
    Write-Host ""
    
    foreach ($platform in $platforms) {
        $password = Generate-SecurePassword -Length 16
        $passwords[$platform] = $password
        
        Write-Host "$($platform.ToUpper()): $password"
    }
    
    Write-Host ""
    Write-Host "=== 安全提醒 ==="
    Write-Host "1. 请将密码安全存储"
    Write-Host "2. 建议使用密码管理器"
    Write-Host "3. 定期更换密码"
    Write-Host "4. 不要重复使用密码"
    
    return $passwords
}

# 生成密码
$generatedPasswords = Generate-PlatformPasswords

# 保存到文件（示例，实际需要加密存储）
$passwordFile = "platform-passwords.json"
$generatedPasswords | ConvertTo-Json | Out-File $passwordFile

Write-Host ""
Write-Host "密码已保存到: $passwordFile"
Write-Host "请确保安全存储此文件！"