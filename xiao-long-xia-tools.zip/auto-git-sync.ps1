# 自动Git同步脚本 - 每天自动备份到Gitee
# 设置Windows计划任务每天运行此脚本

param(
    [string]$Workspace = "C:\Users\89198\.openclaw\workspace",
    [string]$RemoteUrl = "https://little-dragon-shrimp:Wp4592166++@gitee.com/little-dragon-shrimp/memory-backup.git"
)

Write-Host "=== 自动Git记忆同步 ==="
Write-Host "时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host "工作区: $Workspace"
Write-Host "远程仓库: $RemoteUrl"
Write-Host ""

# 切换到工作目录
Set-Location $Workspace

# 检查Git状态
Write-Host "[INFO] 检查Git状态..."
$status = git status --porcelain

if (-not $status) {
    Write-Host "[INFO] 没有检测到记忆变更"
    Write-Host "[SUCCESS] 记忆完整性确认"
    exit 0
}

# 显示变更
Write-Host "[INFO] 检测到记忆变更:"
git status --short
Write-Host ""

# 添加所有变更
Write-Host "[ACTION] 添加记忆变更..."
git add .
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Git添加失败"
    exit 1
}

# 提交变更
Write-Host "[ACTION] 提交记忆变更..."
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$commitMessage = "自动备份: $timestamp - 小龙虾记忆同步"
git commit -m $commitMessage
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Git提交失败"
    exit 1
}

# 推送到Gitee
Write-Host "[ACTION] 推送到Gitee云端..."
git push $RemoteUrl master
if ($LASTEXITCODE -eq 0) {
    Write-Host "[SUCCESS] 记忆已成功同步到Gitee云端!"
    Write-Host "提交信息: $commitMessage"
    Write-Host "访问: https://gitee.com/little-dragon-shrimp/memory-backup"
} else {
    Write-Host "[ERROR] 推送失败，错误码: $LASTEXITCODE"
    Write-Host "[WARN] 本地提交已保存，下次尝试推送"
}

Write-Host ""
Write-Host "=== 同步完成 ==="