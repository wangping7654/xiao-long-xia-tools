# Git Auto Backup Script - Xiao Long Xia Memory Version Control
# Automatically commit memory changes to Git repository

$workspace = "C:\Users\89198\.openclaw\workspace"
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$commitMessage = "Memory update: $timestamp - Xiao Long Xia identity protection"

Write-Host "=== Git Memory Backup System ==="
Write-Host "Time: $timestamp"
Write-Host "Workspace: $workspace"
Write-Host ""

# Change to workspace directory
Set-Location $workspace

# Check for changes
$status = git status --porcelain
if (-not $status) {
    Write-Host "[INFO] No memory changes detected"
    Write-Host "[SUCCESS] Memory integrity confirmed"
    exit 0
}

# Show changes
Write-Host "[INFO] Memory changes detected:"
git status --short
Write-Host ""

# Add all changes
Write-Host "[ACTION] Staging memory changes..."
git add .
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Git add failed"
    exit 1
}

# Commit changes
Write-Host "[ACTION] Committing memory changes..."
git commit -m $commitMessage
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Git commit failed"
    exit 1
}

# Show commit info
$commitHash = git rev-parse --short HEAD
Write-Host ""
Write-Host "[SUCCESS] Memory backup completed!"
Write-Host "Commit hash: $commitHash"
Write-Host "Commit message: $commitMessage"
Write-Host ""
Write-Host "[SUCCESS] Memory versioned, identity history traceable!"